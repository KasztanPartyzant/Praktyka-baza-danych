-- phpMyAdmin SQL Dump
-- version 3.5.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Czas wygenerowania: 21 Maj 2021, 15:46
-- Wersja serwera: 10.4.18-MariaDB-cll-lve
-- Wersja PHP: 5.3.29

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Baza danych: `6524_ktrebnio`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `licencje`
--

CREATE TABLE IF NOT EXISTS `licencje` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `klucz` varchar(40) NOT NULL,
  `data_wygenerowania` datetime NOT NULL,
  `data_wygasniecia` datetime NOT NULL,
  `akceptacja` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Zrzut danych tabeli `licencje`
--

INSERT INTO `licencje` (`id`, `klucz`, `data_wygenerowania`, `data_wygasniecia`, `akceptacja`) VALUES
(1, '3', '2021-05-06 00:00:00', '2022-05-06 00:00:00', 0),
(2, '110ef7505efdf77dfcdc73af3f549a6b7bf5bd98', '2021-05-06 00:00:00', '2022-11-18 00:00:00', 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `produkty`
--

CREATE TABLE IF NOT EXISTS `produkty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `produkt` varchar(32) NOT NULL,
  `cena` int(225) NOT NULL,
  `cena_promocyjna` int(225) NOT NULL,
  `ilosc` int(11) NOT NULL,
  `opis` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT AUTO_INCREMENT=19 ;

--
-- Zrzut danych tabeli `produkty`
--

INSERT INTO `produkty` (`id`, `produkt`, `cena`, `cena_promocyjna`, `ilosc`, `opis`) VALUES
(2, 'Mleko', 300, 250, 20, ''),
(3, 'Woda', 200, 170, 30, ''),
(4, 'platki', 1000, 850, 20, 'brak'),
(5, 'Produkt testowy', 1000, 0, 20, 'dasdsad'),
(6, 'dasdasd', 1000, 0, 1, '2'),
(7, 'Test', 1250, 0, 1, 'dasdasd'),
(9, 'Test', 100000, 90000, 20, ''),
(10, 'Produkt z kontrolki', 100000, 90000, 20, ''),
(11, 'Produkt test 3', 100000, 90000, 20, ''),
(12, 'te', 1800, 0, 1, ''),
(13, 'Test 2 c#', 1000, 900, 1, ''),
(14, 'd', 100, 0, 1, ''),
(15, 'test', 1100, 0, 1, ''),
(16, 'test', 1100, 0, 1, ''),
(17, 'Testowy 5', 1200, 1000, 1, ''),
(18, 'Produkt testowy baza', 1000, 900, 1, 'dasdad');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sprzedaz`
--

CREATE TABLE IF NOT EXISTS `sprzedaz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `produktId` int(11) NOT NULL,
  `data_transakcji` datetime NOT NULL,
  `ilosc_sztuk` int(11) NOT NULL,
  `cena` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `produktId` (`produktId`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Zrzut danych tabeli `sprzedaz`
--

INSERT INTO `sprzedaz` (`id`, `produktId`, `data_transakcji`, `ilosc_sztuk`, `cena`) VALUES
(13, 2, '2021-05-11 00:00:00', 3, 1000),
(14, 5, '2021-05-21 13:34:08', 2, 0),
(15, 4, '2021-05-21 13:34:23', 2, 0),
(16, 2, '2021-05-21 13:35:13', 2, 0),
(17, 13, '2021-05-21 13:37:07', 1, 0),
(18, 3, '2021-05-21 13:37:15', 1, 0),
(19, 4, '2021-05-21 13:39:56', 2, 1000),
(20, 6, '2021-05-21 13:41:12', 1, 1000),
(21, 17, '2021-05-21 15:31:36', 2, 1200),
(22, 9, '2021-05-21 15:34:41', 1, 100000);

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `sprzedaz`
--
ALTER TABLE `sprzedaz`
  ADD CONSTRAINT `sprzedaz_ibfk_3` FOREIGN KEY (`produktId`) REFERENCES `produkty` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
