<?php

return [
    'hostname' => 'localhost',
    'database' => '6524_ktrebnio',
    'username' => '6524_ktrebnio',
    'password' => 'Ka7AM0mJ801l$'
];

?>
